//
//  DetailVC.swift
//  TableviewSample
//
//  Created by Patel, Nirali Arvindbhai on 11/27/19.
//  Copyright © 2019 UHCL. All rights reserved.
//

import UIKit

class DetailVC: UIViewController {
var Passedlabel : Any = []
    
    
    @IBOutlet weak var imgAlbum: UIImageView!
    
    @IBOutlet weak var lblalbumName: UILabel!
    
    @IBOutlet weak var lblArtistName: UILabel!
    
    @IBOutlet weak var lblGenre: UILabel!
    
    @IBOutlet weak var lblReleaseDate: UILabel!
    
    @IBOutlet weak var lblCopyrightInfo: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(Passedlabel)
        var a = (Passedlabel as AnyObject) as? NSDictionary
        var alName = a!["name"] as! String
       // print(alName)
        lblalbumName.text = alName
        
        var artName = a!["artistName"] as! String
        lblArtistName.text = artName
        var genre = a!["kind"] as! String
        
        lblGenre.text = genre
        var relDate = a!["releaseDate"] as! String
        lblReleaseDate.text = relDate
        var copyright = a!["copyright"] as! String
        lblCopyrightInfo.text = copyright
         
        
       let im = a!["artworkUrl100"] as! String
        let image =  UIImage(data: NSData(contentsOf: NSURL(string:im)! as URL)! as Data)
        imgAlbum.image = image
       
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
          // tf1.resignFirstResponder()
           return true
       }
}
